//Display the value of the seventh element of array f.
function displaySeventh()
{
var f = [];
for(var i = 0; i < 10; i++)
f[i] = i+1;
document.write("The value of the seventh element of array f is " + f[6] + "<br >");
}

//Initialize each of the five elements of one-dimensional array g to 8.
function InitializeTo8()
{
var g = [];
for(var i = 0; i < 5; i++)
g[i] = 8;
document.write("The values of array g are <br >");
for(var i = 0; i<5; i++)
document.write(g[i]+"<br >");
}

//Total the elements of array c, which contains 100 numeric elements.
function TotalElements()
{
var sum = 0;
var c = [];
for(var i = 0; i<100; i++)
c[i] = i+1;
for(var i = 0; i<100; i++)
sum += c[i];
document.write("The sum of all values of array c is "+ sum + "<br >");
}

//Copy 11-element array a into the first portion of array b, which contains 34 elements.
function copy11Elements()
{
var a = [];
var b = [];
for(var i = 0; i<11; i++)
a[i] = i+1;
for(var i = 0; i<34; i++)
b[i] = 0;

document.write("Initial values of array b are <br >");
for(var i = 0; i<34; i++)
document.write(b[i]+"<br >");

for(var i = 0; i<11; i++)
b[i] = a[i];

document.write("Final values of array b are <br >");
for(var i = 0; i<34; i++)
document.write(b[i]+"<br >");
}

//Determine and print the smallest and largest values contained in 99-element floatingpoint array w.
function smallestLargest()
{
var w = [];
var smallest;
var largest;
for(var i = 0; i<99; i++)
{
w[i] = i + 0.1;
}
smallest = w[0];
largest = w[0];
for(var i = 1; i<99; i++)
{
if(w[i] < smallest)
smallest = w[i]
else if(w[i] > largest)
largest = w[i]
}
document.write("The smallest value of array w is " + smallest + "<br >");
document.write("The largest value of array w is " + largest + "<br >");
}

// call all the above functions
displaySeventh();
InitializeTo8();
TotalElements();
copy11Elements();
smallestLargest();